import pandas as pd
import numpy as np


def validate_prices(df: pd.DataFrame) -> list[str]:
    required = {"date", "close"}
    missing = required - set(df.columns)
    errors = [f"Eksik sütun: {c}" for c in sorted(missing)]
    if "close" in df.columns:
        if (pd.to_numeric(df["close"], errors="coerce") <= 0).any():
            errors.append("Kapanış fiyatında sıfır veya negatif değer var.")
    if "date" in df.columns:
        parsed = pd.to_datetime(df["date"], errors="coerce")
        if parsed.isna().any():
            errors.append("Geçersiz tarih değeri var.")
    return errors


def price_metrics(df: pd.DataFrame) -> dict:
    data = df.copy()
    data["date"] = pd.to_datetime(data["date"])
    data["close"] = pd.to_numeric(data["close"], errors="coerce")
    data = data.dropna(subset=["date", "close"]).sort_values("date")
    if data.empty:
        return {}
    returns = data["close"].pct_change().dropna()
    wealth = data["close"] / data["close"].iloc[0]
    drawdown = wealth / wealth.cummax() - 1
    return {
        "start": data["date"].iloc[0].date().isoformat(),
        "end": data["date"].iloc[-1].date().isoformat(),
        "last_close": float(data["close"].iloc[-1]),
        "period_return": float(wealth.iloc[-1] - 1),
        "annualized_volatility": float(returns.std() * np.sqrt(252)) if len(returns) > 1 else None,
        "max_drawdown": float(drawdown.min()),
        "observations": int(len(data)),
    }


def basic_signal(metrics: dict) -> str:
    if not metrics:
        return "VERİ YOK"
    if metrics["max_drawdown"] <= -0.30:
        return "RİSK İNCELEMESİ"
    if metrics["period_return"] > 0 and (metrics["annualized_volatility"] or 0) < 0.45:
        return "ARAŞTIR"
    return "İZLE"
