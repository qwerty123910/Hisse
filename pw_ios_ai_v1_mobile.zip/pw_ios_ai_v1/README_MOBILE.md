# PW-IOS AI V1 — Mobile

Bu sürüm Streamlit'in mobil tarayıcıda rahat kullanılabilmesi için düzenlenmiştir.

## Bilgisayarda başlatma

```bash
python -m venv .venv

# Windows
.venv\\Scripts\\activate

# macOS / Linux
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

## Telefonda kullanma

1. Uygulamayı bilgisayarda veya erişilebilir bir sunucuda çalıştır.
2. Streamlit'in gösterdiği yerel/ağ adresini telefonda aç.
3. CSV dosyasını telefondan yükle.
4. Tarayıcı menüsünden **Ana ekrana ekle** seçeneği varsa kullan.

> Not: Bu uygulama henüz canlı veri çekmez ve otomatik emir göndermez. Mobil uyumluluk, arayüz katmanına ilişkindir; güvenilir veri ve yatırım motorları sonraki sürümlerde eklenecektir.
