import pandas as pd
from pwios.analytics import validate_prices, price_metrics


def test_metrics():
    df = pd.DataFrame({"date": ["2026-01-01", "2026-01-02", "2026-01-03"], "close": [100, 110, 105]})
    assert validate_prices(df) == []
    result = price_metrics(df)
    assert round(result["period_return"], 4) == 0.05
    assert result["max_drawdown"] < 0


def test_invalid_price():
    df = pd.DataFrame({"date": ["2026-01-01"], "close": [0]})
    assert validate_prices(df)
