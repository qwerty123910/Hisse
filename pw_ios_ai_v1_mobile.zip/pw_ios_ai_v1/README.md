# PW-IOS AI Investment Intelligence V1

Ücretsiz, yerel ve araştırma odaklı başlangıç sürümü.

## Kurulum

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Kapsam
- Varlık evreni CSV içe aktarma
- Fiyat CSV içe aktarma
- Basit trend/volatilite/maksimum düşüş metrikleri
- Risk uyarıları
- Veri kalitesi kontrolü
- LLM olmadan çalışan temel tarama

Bu sürüm yatırım emri vermez ve gerçek zamanlı veri garantisi içermez.
