import streamlit as st
import pandas as pd
import plotly.express as px
from pwios.analytics import validate_prices, price_metrics, basic_signal

st.set_page_config(
    page_title="PW-IOS AI",
    page_icon="📈",
    layout="centered",
    initial_sidebar_state="collapsed",
)

# Mobile-first styling. Streamlit automatically adapts to narrow screens;
# these rules reduce padding, prevent horizontal overflow, and improve touch use.
st.markdown(
    """
    <style>
    [data-testid="stAppViewContainer"] { padding: 0 0.35rem; }
    [data-testid="stHeader"] { background: transparent; }
    [data-testid="stSidebar"] { min-width: 280px; }
    .block-container { max-width: 1100px; padding: 1rem 0.65rem 3rem; }
    h1 { font-size: clamp(1.45rem, 6vw, 2.2rem) !important; line-height: 1.15 !important; }
    h2 { font-size: clamp(1.15rem, 5vw, 1.55rem) !important; }
    h3 { font-size: 1.05rem !important; }
    .stButton button, .stDownloadButton button { min-height: 2.7rem; border-radius: 0.75rem; }
    [data-testid="stMetric"] { padding: 0.55rem 0.65rem; border: 1px solid rgba(128,128,128,.22); border-radius: .8rem; }
    [data-testid="stMetricValue"] { font-size: clamp(1rem, 5vw, 1.55rem); }
    [data-testid="stDataFrame"] { max-width: 100%; overflow-x: auto; }
    @media (max-width: 640px) {
      .block-container { padding: .65rem .45rem 2rem; }
      [data-testid="stHorizontalBlock"] { gap: .45rem; }
      .stMarkdown p { font-size: .94rem; }
      [data-testid="stMetricLabel"] { font-size: .72rem; }
      [data-testid="stMetricValue"] { font-size: 1.05rem; }
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.title("📈 PW-IOS AI")
st.caption("Mobil uyumlu yerel yatırım araştırma prototipi · Emir vermez")

with st.expander("⚙️ Veri yükle ve ayarlar", expanded=True):
    uploaded = st.file_uploader("Fiyat CSV dosyası", type=["csv"])
    st.caption("Zorunlu sütunlar: date, close · İsteğe bağlı: open, high, low, volume")
    st.info("Mobilde kullanım: CSV dosyanı telefondan seçebilir veya bilgisayarda hazırlayıp telefonuna gönderebilirsin.")

if uploaded is None:
    st.subheader("Başlamak için örnek veri")
    st.code(
        "date,close\n2026-01-02,100\n2026-01-05,102\n2026-01-06,101\n2026-01-07,106",
        language="csv",
    )
    st.warning("Bu sürüm canlı piyasa verisi çekmez. CSV yüklediğinde temel fiyat analizini gösterir.")
    st.stop()

try:
    df = pd.read_csv(uploaded)
except Exception as exc:
    st.error(f"CSV okunamadı: {exc}")
    st.stop()

errors = validate_prices(df)
if errors:
    st.error("Veri doğrulama başarısız")
    for error in errors:
        st.write(f"- {error}")
    st.stop()

metrics = price_metrics(df)
signal = basic_signal(metrics)

st.subheader("📊 Özet")
# Four columns on desktop; Streamlit stacks them on narrow/mobile layouts.
c1, c2, c3, c4 = st.columns(2)
c1.metric("Son kapanış", f"{metrics['last_close']:.2f}")
c2.metric("Dönem getirisi", f"{metrics['period_return']:.2%}")
c3.metric(
    "Yıllık volatilite",
    "N/A" if metrics["annualized_volatility"] is None else f"{metrics['annualized_volatility']:.2%}",
)
c4.metric("Maksimum düşüş", f"{metrics['max_drawdown']:.2%}")

st.subheader(f"Sistem durumu: {signal}")
st.caption(f"Veri dönemi: {metrics['start']} → {metrics['end']} · Gözlem: {metrics['observations']}")

plot_df = df.copy()
plot_df["date"] = pd.to_datetime(plot_df["date"])
plot_df["close"] = pd.to_numeric(plot_df["close"])
plot_df = plot_df.sort_values("date")
fig = px.line(plot_df, x="date", y="close", title="Kapanış fiyatı")
fig.update_layout(
    autosize=True,
    height=330,
    margin=dict(l=10, r=10, t=55, b=10),
    xaxis_title=None,
    yaxis_title=None,
)
fig.update_xaxes(fixedrange=True)
fig.update_yaxes(fixedrange=True)
st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False, "responsive": True})

with st.expander("📋 Veri önizleme", expanded=False):
    st.dataframe(df.tail(20), use_container_width=True, hide_index=True)

with st.expander("🧭 Sonraki geliştirmeler", expanded=False):
    st.markdown(
        "- Makro veri entegrasyonu\n"
        "- BIST ve ABD veri kaynakları\n"
        "- Finansal tablo analizi\n"
        "- Risk ve stres testleri\n"
        "- Portföy takip ekranı\n"
        "- Yapay zekâ destekli raporlar"
    )

st.warning(
    "Bu prototip yalnızca temel fiyat metrikleri hesaplar. Canlı veri, makro analiz, "
    "finansal tablo analizi, işlem maliyeti, VİOP/varant modülü ve otomatik emir entegrasyonu henüz yoktur."
)
